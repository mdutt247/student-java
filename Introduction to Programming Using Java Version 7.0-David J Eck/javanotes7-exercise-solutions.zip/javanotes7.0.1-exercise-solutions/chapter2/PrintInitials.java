
    public class PrintInitials {
      
       /*  This program prints my initials (DJE) in big letters,
           where each letter is nine lines tall.
       */
    
       public static void main(String[] args) {
          System.out.println();
          System.out.println("           ******           *************        **********");
          System.out.println("           **    **                **            **");
          System.out.println("           **     **               **            **");
          System.out.println("           **      **              **            **");
          System.out.println("           **      **              **            ********");
          System.out.println("           **      **       **     **            **");
          System.out.println("           **     **         **    **            **");
          System.out.println("           **    **           **  **             **");
          System.out.println("           *****               ****              **********");
          System.out.println();
       }  // end main()

    }  // end class
   