import Packages.One;
class Example
{
 public static void main(String args[])
 {
 One A= new One();
 A.display();
 }
}