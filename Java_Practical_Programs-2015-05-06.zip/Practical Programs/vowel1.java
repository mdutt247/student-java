import java.io.*;

class vowel1
{
	public static void main(String args[])throws IOException
	{
		
		String vow="venky";
		
		int len=vow.length();
		int i=0;
		
		for(i=0;i<len;i++)
			{
				System.out.println(vow.charAt(i));
			}
	}
}