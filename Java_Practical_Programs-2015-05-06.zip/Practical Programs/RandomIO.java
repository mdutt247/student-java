//Random
import java.io.*;

class RandomIO
{
	public static void main(String args[])throws IOException
	{
		
		RandomAccessFile file=null;
		
		file=new RandomAccessFile("rand.txt","rw");
		
		file.writeChar('X');
		file.writeInt(777);
		file.writeDouble(3.1412);
		
		file.seek(0);
		
		System.out.println(file.readChar());
		System.out.println(file.readInt());
		System.out.println(file.readDouble());
		
		file.seek(2);
		
		System.out.println(file.readInt());
		
		file.seek(file.length());
		
		file.writeBoolean(false);
		
		file.seek(4);
		
		System.out.println(file.readBoolean());
		
		System.out.println(file.length());
		
		file.close();
	}
}