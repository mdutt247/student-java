import java.io.*;
class perfectno
{
	public static void main(String args[])
	{
		/* int calc = 0; int rem = 0;int range = 0;  
		for(int i = 2; i <= 1000; i++)  
        {  
            for(int j = 1; j < i; j++)  
            {  
                rem = i % j;  
                if(rem == 0)  
                calc = calc + j;  
            }      
                if(calc == i)  
                {  
                System.out.println("This number " + i + " is a perfect number.");  
                }  
                calc = 0;  
        }   */
		
		
		int calc = 0; int rem = 0;  
		 int i=10;
            for(int j = 1; j < i; j++)  
            {  
                rem = i % j;  
                if(rem == 0)  
                calc = calc + j;  
            }      
                if(calc == i)  
                {  
                System.out.println("This number " + i + " is a perfect number.");  
                }  
				else{
				System.out.println("This number " + i + " is not a perfect number.");
				}
                calc = 0;  
        
	
	}
}