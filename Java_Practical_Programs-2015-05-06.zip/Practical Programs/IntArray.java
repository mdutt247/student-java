// Integer Array
import java.io.*;

class IntArray
{
	DataInputStream disObj = new DataInputStream(System.in);
	
	int arr[];
	
	void getdata()throws IOException
	{
		int i;
		arr=new int[10];
		for(i=0;i<=5;i++)
		{
		int j=i+1;
		System.out.print("Enter Number "+j+": ");
		arr[i]=Integer.parseInt(disObj.readLine());
		}
	}
	
	void high()
	{
		int i;
		int max=0;
		for(i=0;i<=5;i++)
		{
		if(arr[i]>max)
		{
			max=arr[i];
		}
		}
		System.out.println("\nHighest Number: "+max);
	}
	
	void low()
	{
		int i;
		int low=arr[0];
		for(i=0;i<=5;i++)
		{
		if(arr[i]<low)
		{
			low=arr[i];
		}
		}
		System.out.println("\nLowest Number: "+low);
	}
	
	void items()
	{
		int i;
		int count=0;
		for(i=0;i<=5;i++)
		{
		if(arr[i]>0)
		{
			count++;
		}
		}
		System.out.println("\nNumber of Items: "+count);
		System.out.println("\nTotal Number of Items: "+arr.length);
	}
	
	void odd()
	{
		int i;
		System.out.println("\nOdd Numbers:");
		for(i=0;i<=5;i++)
		{
		if(arr[i]%2!=0)
		{
			System.out.println(arr[i]);
		}
		}
		
	}
	
	public static void main(String args[])throws IOException
	{
		IntArray A=new IntArray();
		A.getdata();
		A.high();
		A.low();
		A.items();
		A.odd();
	}
}
