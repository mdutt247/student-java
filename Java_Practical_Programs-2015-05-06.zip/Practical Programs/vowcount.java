import java.io.*;
class vowcount
{
	public static void main(String args[])
	{
		String str;
		str=args[0];
		int len=str.length();
		int count=0;
	
		for(int i=0;i<=len-1;i++)
		{
			if(str.charAt(i)=='a'||str.charAt(i)=='e'||str.charAt(i)=='i'||str.charAt(i)=='o'||str.charAt(i)=='u')
			{
				count++;
			}
		}
		
		System.out.println("No. of vowels are: "+count);
	}
}