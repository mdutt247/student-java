//Q1: Create a class Student with roll no, name, marks for 4 subjects as data members.....
import java.io.*;
class Student
{
	static int count;
	static int oppcount;
	int roll;
	String name;
	int[] marks = new int[4];
	
	Student()
	{
		count=count+1;
		oppcount=count;
	}
	
	DataInputStream dis = new DataInputStream(System.in);
	
	void getdata()throws IOException
	{
		oppcount=oppcount-1;
		System.out.println("");
		System.out.println("Enter Details of Student "+(count-(oppcount))+":");
		System.out.println("");
		System.out.print("Enter Roll Number: ");
		roll=Integer.parseInt(dis.readLine());
		
		System.out.print("Enter Student Name: ");
		name=dis.readLine();
		
		for(int i=0; i<=3; i++)
		{
			System.out.print("Enter Marks for Subject "+(i+1)+": ");
			marks[i]=Integer.parseInt(dis.readLine());
		}
	}
	
	void putdata()
	{
		System.out.println("");
		System.out.println("***-----***");
		System.out.println("");
		
		System.out.println("Roll Number: "+roll);
		System.out.println("Student Name: "+name);
		System.out.println("");
		System.out.println("Mark Sheet:");
		
		int sum=0;
		float perc;
		for(int i=0; i<=3; i++)
		{
			System.out.println("Subject "+(i+1)+": "+marks[i]);
			sum=sum+marks[i];
			
		}
		perc=(sum/400f)*100;
		System.out.println("");
		System.out.println("Total Marks: "+sum);
		System.out.println("Percentage: "+perc+"%");
	}
}

class StudentMarks
{
	public static void main(String args[])throws IOException
	{
		Student S1 = new Student();
		Student S2 = new Student();
		Student S3 = new Student();
		
		S1.getdata();
		S2.getdata();
		S3.getdata();
		
		S1.putdata();
		S2.putdata();
		S3.putdata();
	}
}