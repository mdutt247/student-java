/*
 A
 B B
 C C C
 D D D D
 E E E E E*/

class b8
{
public static void main(String args[])

{
int i,j;
String ch;

for(i=65;i<=69;i++)
   {

      for(j=65;j<=i;j++)
      {
	   
		System.out.print((char)i);
	  }
	 
	  
    System.out.print('\n');
   }
}
}