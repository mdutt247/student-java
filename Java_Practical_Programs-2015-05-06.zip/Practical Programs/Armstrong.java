import java.io.*;

class Armstrong
{
	public static void main(String args[])throws IOException
	{
	int num;
	int temp, rem, sum=0;
	DataInputStream dis = new DataInputStream(System.in);
	
	System.out.println("To Check if Armstrong Number");
	System.out.print("\nEnter a number: ");

	num=Integer.parseInt(dis.readLine());
	
	temp=num;
	
	while(temp!=0)
	{
		rem=temp%10;
		sum=sum+(rem*rem*rem);
		temp=temp/10;
	}
	
	if (num==sum)
	{
         System.out.println("Entered number is an Armstrong number.");
	}
    else
    {
		System.out.println("Entered number is not an Armstrong number.");
	}
}
}