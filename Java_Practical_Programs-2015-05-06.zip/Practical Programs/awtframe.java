import java.awt.*;
import java.applet.*;

class awtframe
{
	public awtframe()
	{
		Frame f=new Frame();
		f.setSize(500,500);
		f.setLayout(new FlowLayout());
		f.setVisible(true);
		
		f.setBackground(Color.white);
		Label l1=new Label("Hi");
		l1.setBounds(100,100,200,30);
		f.add(l1);
		
		Button b1=new Button("One");
		b1.setBounds(150,150,150,30);
		f.add(b1);
		
	}
	
	public static void main(String args[])
	{
		new awtframe();
	}
}