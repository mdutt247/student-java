// Input Values from User in JAVA
import java.io.*;

class StringRepeat
{
	public static void main(String args[])throws IOException
	{
		DataInputStream disObj = new DataInputStream(System.in);
		
		String name;
		int count;
		int i;
		
		System.out.print("Enter your name: ");
		name=disObj.readLine();
		
		System.out.print("Enter the count to repeat your name: ");
		count=Integer.parseInt(disObj.readLine());
		
		System.out.println("");
		
		for(i=1; i<=count; i++)
		{
		System.out.println(name);
		}
	}
}