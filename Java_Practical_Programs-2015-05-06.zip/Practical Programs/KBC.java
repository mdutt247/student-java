import java.io.*;

class KBC
{
	public static void main(String arga[])throws IOException
	{
	String[][] LQ= new String[4][4];
	String[][] LA= new String[4][4];
	String ANS;
	int Count=0, Grand=0;
	int i, j, k;
	int[] LBase= new int[4];
	int[] LTotal= new int[4];
	int[] LGrand= new int[4];
	//int i, L1Base=0, L1Total=500, L1Grand=0;
	//int j, L2Base=0, L2Total=500, L2Grand=0;
	//int k, L3Base=0, L3Total=500, L3Grand=0;
	int skipcount=0, skip=0;
	
	//Question-Answers for Level 1
	LQ[0][0]="1. What is the Capital of India?";
	LA[0][0]="DELHI";
	
	LQ[0][1]="2. What is the Economic Capital of India?";
	LA[0][1]="MUMBAI";
	
	LQ[0][2]="3. Which is the Largest Continent on the World?";
	LA[0][2]="ASIA";
	
	//Question-Answers for Level 2
	LQ[1][0]="1. Which is the latest version of Windows?";
	LA[1][0]="WINDOWS 8";
	
	LQ[1][1]="2. iPhone is made by?";
	LA[1][1]="APPLE";
	
	LQ[1][2]="3. Which is the most populated country?";
	LA[1][2]="CHINA";
	
	//Question-Answers for Level 3
	LQ[2][0]="1. Which is the highest grosser movie in Indian Film industry?";
	LA[2][0]="DHOOM 3";
	
	LQ[2][1]="2. Which was the last movie of Shah Rukh Khan?";
	LA[2][1]="CHENNAI EXPRESS";
	
	LQ[2][2]="3. Which is the upcoming movie of superstar **RAJNIKANT**?";
	LA[2][2]="KOCHADAIIYAAN";
	
	DataInputStream qin = new DataInputStream(System.in);
	
	System.out.println("\nWelcome to KBC 2014");
	System.out.println("\nAll your ANSWERS must be in CAPS!\nUse SKIP Lifeline wherever needed.");
	System.out.println("\nLevel 1: (3 Questions)");

	for(i=0;i<=2;)
	{
		for(j=0;j<=2;)
		{
		System.out.print(LQ[i][j]+" Ans: ");
		ANS=qin.readLine();
			if(ANS.equals(LA[i][j]))
			{
			LTotal[i]=(LTotal[i])+(LBase[i]*2);
			LBase[i]=LBase[i]+500;
			j++;
			Count++;
			LGrand[i]=LTotal[i];
			System.out.println("You have earned: Rs."+LGrand[i]+"\n");
			}
			else if(ANS.equals("SKIP") && skipcount==0)
			{
			skipcount++;
			LTotal[i]=(LTotal[i])+(LBase[i]*2);
			LBase[i]=LBase[i]+500;
			j++;
			Count++;
			LGrand[i]=LTotal[i];
			System.out.println("You have earned: Rs."+LGrand[i]+"\n");
			}
			else if(ANS.equals("SKIP") && skipcount>=1)
			{
			System.out.println("You have used SKIP lifeline already!\n");
			}
			else
			{
			break;
			}
		}
		i++;
	}
	
	Grand=LGrand[0]+LGrand[1]+LGrand[2];
	if(Grand>0)
	{
	System.out.println("\n***GOOD ATTEMPT! YOU HAVE WON RS."+Grand+"***");
	java.awt.Toolkit.getDefaultToolkit().beep();
	}
	else if(Grand==10500)
	{
	System.out.println("\n*****CONGRATS! YOU HAVE WON KBC 2014 WITH RS."+Grand+"*****");
	java.awt.Toolkit.getDefaultToolkit().beep();
	}
	else
	{
	System.out.println("\007\n***NO PRIZE! BETTER LUCK NEXT TIME!***");
	}
	}
}