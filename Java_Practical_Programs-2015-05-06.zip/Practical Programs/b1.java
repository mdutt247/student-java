//Prime no
import java.io.*;
class b1
{
public static void main(String args [])throws IOException
{
int num,i,j;
DataInputStream B= new DataInputStream(System.in);

System.out.print("Enter The Number Which You Want To Check:");

num=Integer.parseInt(B.readLine());
i=2;
while(i<=num-1)
{
    if(num%i==0)
    {
     System.out.println("Not A Prime Number ");
     break;
    }
    i++;
}
if ((num==i)||(num==1))
{
System.out.println("It Is a Prime Number ");
}


}

}

