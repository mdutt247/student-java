/** Pattern 2
1
0 1
1 0 1
0 1 0 1
1 0 1 0 1
**/

import java.io.*;

class Pattern2
{
	public static void main(String args[])throws IOException
	{
		int i=0, j=0;
		
		for(i=1; i<=5; i++)
		{
			
			for(j=1; j<=1; j++)
			{
				System.out.print(j);
			}
			System.out.println("");
		}
		
		
		
	}
}