import java.awt.*;

public class MyFrame
{
  public MyFrame()
  {
   Frame f = new Frame();
   f.setSize(500,500);
   f.setVisible(true);
  }
  public static void main(String args[])
  {
    new MyFrame();  
  }
}