import java.awt.*;
import java.applet.*;
/*
<applet code="FontApplet.class" width=300 height=200>
</applet>
*/
public class FontApplet extends Applet
{
  public void paint(Graphics g)
  {
  
	Label test = new Label("Hello");
	test.setBounds(10,50,100,20);
	add(test);
	
    Font font = new Font("Aharoni",Font.BOLD,30);
    g.setFont(font);
	test.setFont(font);
	
    FontMetrics fm = g.getFontMetrics();
    g.setColor(Color.BLACK);

    // first set y to the first line that will be on-screen
    int y = fm.getHeight();
    // draw a line of text there
    g.drawString("Hello World",10,y);

  }
}