import java.io.*;

class staticvar
{
	int a,b;
	static int count;
	
	staticvar()
	{
	a=10;
	b=20;
	count++;
	}
	
	static int mul(int x, int y)
	{
	return x*y;
	}
	
	static int div(int x, int y)
	{
	return (x/y);
	}
}

class staticeg
{
	public static void main(String args[])throws IOException
	{
	staticvar A = new staticvar();
	
	int p = staticvar.mul(15,20);
	int v = staticvar.div(15,5);
	
	System.out.println(p);
	System.out.println(v);
	System.out.println(staticvar.count);
	}
}


