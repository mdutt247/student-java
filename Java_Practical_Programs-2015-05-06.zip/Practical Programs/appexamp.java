import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
<applet code="appexamp.class" width=700 height=350>
</applet>
*/
public class appexamp extends Applet implements ActionListener
{
	Label lhead;
	Label lname;
	Label lemail;
	Label lgender;
	Label lqual;
	Label lhobbies;
	Label lcity;
	Label lcomments;
	TextField tname;
	TextField temail;
	CheckboxGroup cggender;
	Checkbox cmale;
	Checkbox cfemale;
	Checkbox cgrad;
	Checkbox cpgrad;
	Checkbox cothers;
	List lthobbies;
	Choice ccity;
	TextArea tcomments;
	Button bsubmit;
	
public void init()
{
		FlowLayout f1 = new FlowLayout(FlowLayout.CENTER);
		setLayout(null);
		
		lhead = new Label("Registration Form");
		lhead.setBounds(300,10,120,20);
		lhead.setBackground(Color.yellow);
		add(lhead);
		
		lname = new Label("Name: ");
		lname.setBounds(25,40,80,20);
		lname.setBackground(Color.blue);
		add(lname);
		
		tname = new TextField(15);
		tname.setBounds(110,40,120,20);
		add(tname);
		
		lemail = new Label("E-Mail: ");
		lemail.setBounds(25,70,80,20);
		add(lemail);
		
		temail = new TextField(15);
		temail.setBounds(110,70,120,20);
		add(temail);
		
		lgender = new Label("Gender: ");
		lgender.setBounds(25,100,80,20);
		add(lgender);
		
		cggender = new CheckboxGroup();
		cmale = new Checkbox("Male", cggender, false);
		cfemale = new Checkbox("Female", cggender, false);
		cmale.setBounds(110,100,50,20);
		cfemale.setBounds(170,100,80,20);
		add(cmale);
		add(cfemale);
		
		lqual = new Label("Qualification: ");
		lqual.setBounds(25,130,80,20);
		add(lqual);
		
		cgrad = new Checkbox("Graduate");
		cpgrad = new Checkbox("Post-Graduate");
		cothers = new Checkbox("Others");
		cgrad.setBounds(110,130,80,20);
		cpgrad.setBounds(200,130,100,20);
		cothers.setBounds(310,130,80,20);
		add(cgrad);
		add(cpgrad);
		add(cothers);
		
		lhobbies = new Label("Hobbies: ");
		lhobbies.setBounds(25,160,80,20);
		add(lhobbies);
		
		lthobbies = new List(5,true);
		lthobbies.add("Music");
		lthobbies.add("Games");
		lthobbies.add("Cricket");
		lthobbies.add("Reading");
		lthobbies.add("Dance");
		lthobbies.setBounds(110,160,100,60);
		add(lthobbies);
		
		lcity = new Label("City: ");
		lcity.setBounds(25,230,80,20);
		add(lcity);
		
		ccity = new Choice();
		ccity.add("Mumbai");
		ccity.add("Chennai");
		ccity.add("Delhi");
		add(ccity);
		ccity.setBounds(110,230,120,20);
		
		lcomments = new Label("Comments: ");
		lcomments.setBounds(25,260,80,20);
		add(lcomments);
		
		tcomments = new TextArea("",10,30);
		tcomments.setBounds(110,260,160,60);
		add(tcomments);
		
		bsubmit = new Button("Submit");
		bsubmit.setBounds(300,330,120,20);
		add(bsubmit);  
	 	bsubmit.addActionListener(this);
		
}

	public void actionPerformed(ActionEvent e)
	{
			String s1=e.getActionCommand();
			
			String a1=tname.getText();
			String a2=temail.getText();
			String a3=cggender.getSelectedCheckbox().getLabel()+" ";
			String a4=cgrad.getLabel()+": "+cgrad.getState()+"  ";
			String a5=cpgrad.getLabel()+": "+cpgrad.getState()+"  ";
			String a6=cothers.getLabel()+": "+cothers.getState()+"  ";
			String[] a7=lthobbies.getSelectedItems();
			String a8="";
			String a9=ccity.getSelectedItem();
			String a10=tcomments.getText();
			
			if(s1.equals("Submit"))
			{
				remove(tname);
				remove(temail);
				remove(cmale);
				remove(cfemale);
				remove(cgrad);
				remove(cpgrad);
				remove(cothers);
				remove(lthobbies);
				remove(ccity);
				remove(tcomments);
				remove(bsubmit);
				
				lhead.setText("Form Output");
				remove(lcity);
				remove(lcomments);
				lcity.setBounds(25,190,80,20);
				lcomments.setBounds(25,220,80,20);
				add(lcity);
				add(lcomments);
				
				Label d1 = new Label(a1);
				d1.setBounds(110,40,400,20);
				Label d2 = new Label(a2);
				d2.setBounds(110,70,400,20);
				Label d3 = new Label(a3);
				d3.setBounds(110,100,400,20);
				Label d4 = new Label(a4+a5+a6);
				d4.setBounds(110,130,400,20);
				
				for(int i=0;i<a7.length;i++)
				{
					a8=a7[i]+"  "+a8;
				}
				
				Label d5 = new Label(a8);
				d5.setBounds(110,160,400,20);
				
				Label d6 = new Label(a9);
				d6.setBounds(110,190,400,20);
				
				Label d7 = new Label(a10);
				d7.setBounds(110,220,400,20);
				
				add(d1);
				add(d2);
				add(d3);
				add(d4);
				add(d5);
				add(d6);
				add(d7);
			}
			
			repaint();
	}
	
	
	public void paint(Graphics g)
	{
		
	}
}