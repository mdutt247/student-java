//Q2: WAP in Java to show constructor overloading
import java.io.*;

class Sum
{
	int a, b;
	
	Sum()
	{
		a=b=0;
	}
	
	Sum(int x)
	{
		a=x;
		b=0;
	}
	
	Sum(int x, int y)
	{
		a=x;
		b=y;
	}
	
	void display()
	{
		System.out.println("Sum is: "+(a+b));
	}
}

class ConstrOverload
{
	public static void main(String args[])
	{
	Sum A = new Sum(10);
	A.display();
	Sum B = new Sum(10,10);
	B.display();
	Sum C = new Sum();
	C.display();
	}
}