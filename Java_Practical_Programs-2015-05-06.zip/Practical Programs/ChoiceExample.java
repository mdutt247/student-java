import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/* <applet code="choiceExample" width=250 height=300></applet> */

public class choiceExample extends Applet implements ItemListener
{
	Choice sports;
	String s="";
	
	public void init()
	{
		sports = new Choice();
		sports.add("Swimming");
		sports.add("Hockey");
		sports.add("Cricket");
		sports.add("Football");
		
		add(sports);
		sports.addItemListener(this);
		
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		repaint();
	}
	
	public void paint(Graphics g)
	{
		s="Current Sports: ";
		s+=sports.getSelectedItem();
		g.drawString(s,10,200);
	}
}