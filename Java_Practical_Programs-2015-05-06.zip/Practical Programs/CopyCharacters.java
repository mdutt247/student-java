// Copying Characters
import java.io.*;

class CopyCharacters
{
	public static void main(String args[])throws IOException
	{
		
		
		File inFile = new File(args[0]);
		File outFile = new File(args[1]);
		
		FileReader ins=new FileReader(inFile);
		FileWriter outs=new FileWriter(outFile);
		
		int ch;
		
		while((ch=ins.read()) != -1)
		{
			outs.write(ch);
		}
		
		System.out.println("Characters Copied!");
		
		ins.close();
		outs.close();
	}
}