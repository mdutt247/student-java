// Armstrong no by command line
import java.io.*;

class b5
{
	public static void main(String args[])throws IOException
	{
	int num;
	int temp, rem, sum=0;
	num=Integer.parseInt(args[0]);
	
	temp=num;
	
	while(temp!=0)
	{
		rem=temp%10;
		sum=sum+(rem*rem*rem);
		temp=temp/10;
	}
	
	if (num==sum)
	{
         System.out.println("Entered number is an Armstrong number.");
	}
    else
    {
		System.out.println("Entered number is not an Armstrong number.");
	}
}
}