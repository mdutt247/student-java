//WAP to accept a no. & display it in word. E.g. no is 123 as one two three (use switch)
import java.io.*;
class onetwothree
{
	public static void main(String args[])
	{
		String nstr, out="";
		String[] store= new String[10];
		store[0]="Zero";
		store[1]="One";
		store[2]="Two";
		store[3]="Three";
		store[4]="Four";
		store[5]="Five";
		store[6]="Six";
		store[7]="Seven";
		store[8]="Eight";
		store[9]="Nine";
		int num, len, temp;
		int[] set= new int[50];
		nstr=(args[0]);
		num=Integer.parseInt(args[0]);
		len=nstr.length();
		temp=num;
		
		for (int i=0; i<=len; i++)
		{
			
			set[i]=temp%10;
			temp=temp/10;
		}

		for (int j=len-1; j>=0;)
		{
			for (int k=0; k<=9; k++)
			{
				if(set[j]==k)
				{
				System.out.print(store[k]+" ");
				j--;
				break;
				}
			}
		}
		
		System.out.print(out);
	}
}
