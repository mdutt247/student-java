import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/* <applet code="choiceText" width=250 height=300></applet> */

public class choiceText extends Applet implements ItemListener
{
	Choice sports;
	TextField stf;
	String s="";
	String f="";
	Label l1;
	
	public void init()
	{
		sports = new Choice();
		sports.add("Swimming");
		sports.add("Hockey");
		sports.add("Cricket");
		sports.add("Football");

		add(sports);
		sports.addItemListener(this); 
		
		stf = new TextField(15);
		add(stf);
		
		l1 = new Label("Hello");
		add(l1);
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		repaint();
	}
	
	public void paint(Graphics g)
	{
		s="Current Sports: ";
		s+=sports.getSelectedItem();
		g.drawString(s,10,200);
		
		f="";
		f+=sports.getSelectedItem();
		stf.setText(f);
	}
}