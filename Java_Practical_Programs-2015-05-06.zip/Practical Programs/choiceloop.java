import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
<applet code="choiceloop.class" width=700 height=350>
</applet>
*/
public class choiceloop extends Applet
{
public void init()
{
	FlowLayout f1 = new FlowLayout(FlowLayout.CENTER);
    setLayout(null);
	Label DD = new Label("DD :");
    DD.setBounds(10,20,80,30);
    add(DD);
    int i;
	String j="";
	
    Choice cdate = new Choice();
	for (i=1;i<=31;i++)
	{
	j= Integer.toString(i);
	cdate.add(j);
	}
    add(cdate);
	cdate.setBounds(100,25,100,20);
	
	
	Label MM = new Label("MM :");
    MM.setBounds(10,50,80,30);
    add(MM);
	Choice cmon = new Choice();
	for (i=1;i<=12;i++)
	{
	j= Integer.toString(i);
	cmon.add(j);
	}
    add(cmon);
	cmon.setBounds(100,55,100,20);
	
	
	Label YY = new Label("YY :");
    YY.setBounds(10,80,80,30);
    add(YY);
	Choice cyear = new Choice();
	for (i=1980;i<=2050;i++)
	{
	j= Integer.toString(i);
	cyear.add(j);
	}
    add(cyear);
	cyear.setBounds(100,85,100,20);
	

}
public void paint(Graphics g)
{


}

}