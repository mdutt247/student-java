// Generate Multiplication Table with command line
import java.io.*;

class MultiTable
{
	public static void main(String args[])throws IOException
	{
		
		int table, i;
		
		System.out.print("Enter the tables to print: ");
		table=Integer.parseInt(args[0]);
		
		System.out.println("Tables of "+table+":");
		for(i=1;i<=10;i++)
		{
		System.out.println(table+"X"+i+"="+table*i);
		}

	}
}