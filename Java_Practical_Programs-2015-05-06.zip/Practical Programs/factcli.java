import java.io.*;
class factcli
{
	public static void main(String args[])
	{
	int num;
	num=Integer.parseInt(args[0]);
	int fact=1, i=0;
	
	for(i=num; i>=1; i--)
	{
	fact=fact*i;
	}
	
	System.out.println(fact);
	
	}
}