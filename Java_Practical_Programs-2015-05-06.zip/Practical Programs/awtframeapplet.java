//<applet code="awtframeapplet.class" height=600 width=600></applet>

import java.awt.*;
import java.applet.*;


class awtframeapplet extends Applet
{
Label l1=new Label("Hi");
		
		
	public void init()
	{
		//setBackground(Color.blue);
		//Label l1=new Label("Hi");
		//add(l1);
		//Button b1=new Button("One");
		//add(b1);
		
		add(l1);
		//text1.setText("0");
		//l1.setBounds(100,100,200,30);
		
	}
	
	public void paint(Graphics g)
	{
	g.drawString("hello",50,50);
	}
	
}