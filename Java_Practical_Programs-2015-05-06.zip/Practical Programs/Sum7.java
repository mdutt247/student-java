// Sum of all integers greater than 100 and less than 200 that are divisible by 7
import java.io.*;

class Sum7
{
	public static void main(String args[])throws IOException
	{
		int i=0, count=0, sum=0;
		
		for(i=100; i<=200; i++)
		{
		if(i%7==0)
		{
		System.out.println(i);
		sum=sum+i;
		count++;
		}
		}
		
		System.out.println("Count is: "+count);
		System.out.println("Sum is: "+sum);
	}
}