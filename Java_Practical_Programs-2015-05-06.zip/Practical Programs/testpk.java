import packages.one;
import packages.two;

class testpk
{
	public static void main(String args[])
	{
		one A = new one();
		A.display();
		
		two B = new two();
		B.display();
	}
}