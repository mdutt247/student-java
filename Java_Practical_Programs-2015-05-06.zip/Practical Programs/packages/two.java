package packages;

public class two
{
	public void display()
	{
		System.out.println("My second package");
	}
}