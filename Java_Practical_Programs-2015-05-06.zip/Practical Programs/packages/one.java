package packages;

public class one
{
	public void display()
	{
		System.out.println("My first package");
	}
}
