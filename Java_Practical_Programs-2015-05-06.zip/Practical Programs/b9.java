// printing 1-100 with their square and cube
import java.io.*;
class b9
{
 public static void main (String args[])
 {
 int i=1;
 for (i=1;i<=100;i++)
 {
 System.out.println(i+" "+(i*i)+" "+(i*i*i));
 }
 }
} 