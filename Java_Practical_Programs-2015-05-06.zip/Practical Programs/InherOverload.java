//Q3: WAP in Java to show demo of inheritance & overloading
class A
{
	void disp()
	{
		System.out.println("I am disp from Class A");
	}
}
class B extends A
{
	void disp()
	{
		System.out.println("I am disp from Class B");
	}
}

class InherOverload
{
	public static void main(String args[])
	{
		B objB = new B();
		objB.disp();
	}
}