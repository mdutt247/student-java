import java.io.*;

class combi
{
	public static void main(String args[])throws IOException
	{
		int a=9, b=8, c=7;
		int p1, cnt=0;
		int[] str = new int[50];
		
		System.out.println("Hello");
		
	/*	for (int i=0; i<=5; i++)
		{
			
			p1 = a*100 + b*10 + c;
			
			for  (int j=0; j<=i; j++)
			{
				if(str[j]!=p1)
				{
					str[cnt]=p1;
					cnt++;
					System.out.println(p1);
					a=b;
					b=c;
					c=a;
				}
			}
		} */
		str[0]=112;
		str[1]=345;
		str[2]=542;
		
		int k = 0, ct=0;
		while(str[k] != 0)
		{
			System.out.println(str[k]);
			ct++;
			k++;
		}
		System.out.println("Len "+ct);
	/*	p1 = a*100 + b*10 + c;
		System.out.println(p1);
		a=b;
		b=c;
		c=a;
		
		p1 = a*100 + b*10 + c;
		System.out.println(p1); 
		*/
	}
}