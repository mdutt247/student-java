import java.awt.*;
import java.applet.*;

public class Ellipse extends Applet
{
	public void paint(Graphics g)
	{
	//	g.drawOval(20,20,200,120);
		g.setColor(Color.green);
		g.fillOval(100,50,100,100);
	}
}

//<APPLET CODE=Ellipse.class WIDTH=250 HEIGHT=200></APPLET>