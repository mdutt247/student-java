import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
<applet code="listcontr.class" width=450 height=350>
</applet>
*/
public class listcontr extends Applet implements ActionListener, ItemListener
{
	List lleft;
	List lright;
	Button bleft;
	Button bright;

	public void init()
	{
		FlowLayout f1 = new FlowLayout(FlowLayout.CENTER);
		setLayout(null);
		
		lleft = new List(10,false);
		lleft.add("Left 1");
		lleft.add("Left 2");
		lleft.add("Left 3");
		lleft.add("Left 4");
		lleft.add("Left 5");
		lleft.setBounds(50,40,100,150);
		add(lleft);
		lleft.addItemListener(this);
		
		lright = new List(10,false);
		lright.add("Right 1");
		lright.add("Right 2");
		lright.add("Right 3");
		lright.add("Right 4");
		lright.add("Right 5");
		lright.setBounds(300,40,100,150);
		add(lright);
		lright.addItemListener(this);
		
		bleft = new Button("<<");
		bleft.setBounds(90,240,60,20);
		add(bleft);  
		
		bright = new Button(">>");
		bright.setBounds(300,240,60,20);
		add(bright);  
		
		bleft.addActionListener(this);
		bright.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String s1=e.getActionCommand();
		String left, right;
		if(s1.equals("<<"))
		{
			left=lright.getSelectedItem();
			lright.remove(left);
			lleft.add(left);
		}
		else
		{
			right=lleft.getSelectedItem();
			lleft.remove(right);
			lright.add(right);
		}
		
		repaint();
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		repaint();
	}
	
	public void paint(Graphics g)
	{
	}
}