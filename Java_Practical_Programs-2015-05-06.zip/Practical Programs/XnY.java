// Sum of all integers greater than 100 and less than 200 that are divisible by 7
import java.io.*;

class XnY
{
	public static void main(String args[])throws IOException
	{
		int x=5, y=50;
		
		while(x<=y)
		{
		x=y/x;
		System.out.println("Chal raha hoon..");
		}
		
		
	}
}