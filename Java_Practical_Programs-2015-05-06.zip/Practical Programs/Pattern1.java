/** Pattern 1
1
2 2
3 3 3
4 4 4 4
5 5 5 5 5
**/

import java.io.*;

class Pattern1
{
	public static void main(String args[])throws IOException
	{
		int i=0, j=0;
		
		for(i=1; i<=5; i++)
		{
			
			for(j=1; j<=i; j++)
			{
				System.out.print(i);
			}
			System.out.println("");
		}
		
		
		
	}
}