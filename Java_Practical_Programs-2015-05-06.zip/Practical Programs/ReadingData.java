import java.io.*;

class ReadingData
{
 public static void main(String args[])throws IOException
 {
    DataInputStream dis=new DataInputStream(System.in);
	int i=0;
	float f=0.0f;
	char c='a';
	String s=" ";
	
	System.out.println("Enter an Integer number");
	i=Integer.parseInt(dis.readLine());
	
	System.out.println("Enter an float number");
	f=Float.parseFloat(dis.readLine());
	
	System.out.println("Enter the char value");
	c=(char)dis.read();
	
	System.out.println("Enter an string value");
	s=dis.readLine();
	
	System.out.println("The value of i"+i);
	System.out.println("The value of f"+f);
	System.out.println("The value of c"+c);
	System.out.println("The value of s"+s);
	
 }
}
