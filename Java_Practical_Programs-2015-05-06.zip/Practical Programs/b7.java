/*
 A B C D E
   B C D E 
     C D E
	   D E
	     E */

class b7
{
public static void main(String args[])

{
int i,j,k;
String ch;

for(i=65;i<=69;i++)
   {
   for(k=65;k<=i;k++)
      {
	   
		System.out.print(" ");
	  }
      for(j=i;j<=69;j++)
      {
	   
		System.out.print((char)j);
	  }
	 
	  
    System.out.print('\n');
   }
}
}