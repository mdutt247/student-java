//<APPLET CODE=Admission.class WIDTH=1000 HEIGHT=500></APPLET>
import java.awt.*;
import java.applet.*;

public class Admission extends Applet
{
	Label lhead=new Label("Welcome to GARIBSAR!");
	
	public void init()
	{
		add(lhead);
	}
	
}