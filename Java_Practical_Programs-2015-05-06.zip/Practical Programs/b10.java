/*

1. *
   **
   ***
   ****
   ***** 

2. *****
   ****
   ***
   **
   *
3.     *
      * *
	 * * *
	* * * *
   * * * * *

*/
class b10
{
public static void main(String args[])

{
int c,i,j,k,l,m,n,o,p;

c=Integer.parseInt(args[0]);


if(c==1)
{ 
 for(i=1;i<=5;i++)
   {
   
      for(j=1;j<=i;j++)
      {
		System.out.print("*");
	  }
	  
    System.out.print('\n');
   }
}
else if(c==2)
{
 for(i=5;i>=1;i--)
   {
   
      for(j=1;j<=i;j++)
      {
		System.out.print("*");
	  }
	  
    System.out.print('\n');
   }
}
else if(c==3)
{
 for(i=1;i<=5;i++)
   {
   
      for (k=i;k<=4;k++)
      {
	     System.out.print(" ");
      }
      for(j=1;j<=i;j++)
      {
		System.out.print("*"+" ");
	  }

	  
    System.out.print('\n');
	}
}

}
}