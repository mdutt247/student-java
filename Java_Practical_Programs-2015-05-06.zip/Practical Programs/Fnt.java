import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
<applet code="Fnt.class" width=300 height=200>
</applet>
*/
public class Fnt extends Applet
{
	public void paint(Graphics g)
	{
		String s = "";
		String FList[];
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		FList = ge.getAvailableFontFamilyNames();
		int len = FList.length;
		for(int i=0; i<len; i++)
		{ s+=FList[i]+" "; }
		
		String lens=Integer.toString(len);
		g.drawString(lens,10,10);
		g.drawString(s,10,20);
	}
}