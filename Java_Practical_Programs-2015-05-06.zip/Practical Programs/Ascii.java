// Print ASCII Value
import java.io.*;

class Ascii
{
	public static void main(String args[])throws IOException
	{
		DataInputStream disObj = new DataInputStream(System.in);
		
		int ch;
		
		System.out.print("Enter a character: ");
		ch=Integer.parseInt(disObj.readLine());
		
		System.out.println("ASCII Value is: "+ch);
		
	}
}