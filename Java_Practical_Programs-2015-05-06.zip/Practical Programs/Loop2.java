//Infinite Loop

import java.io.*;
import packages.one;

class Loop2
{
	public static void main(String args[])throws IOException
	{
		int i=0;
		
		for(i=1; i<=10; i++)
		{
		if(i==3)
		break;
		System.out.println(i);
		}

		one A = new one();
		A.display();
	}
}