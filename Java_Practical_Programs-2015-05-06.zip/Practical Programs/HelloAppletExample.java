import java.awt.*;
import java.applet.*;
public class HelloAppletExample extends Applet 
{
String str;
public void init()
 {
    str= getParameter("String");
	if (str==null)
    str ="shilpa";
    str ="HI" + str;	
 }
public void paint(Graphics g)
 { 
   g.drawString("Hello bhagyesh",10,100);
 }
}
