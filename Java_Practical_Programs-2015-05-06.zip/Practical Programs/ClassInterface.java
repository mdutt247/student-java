//Derive a class Square from class Rect. Create another class Circle.
//Create an interface with only one method called Area().
//Implement this interface in all classes. Include appropriate data member and constructor in all classes.
import java.io.*;
import java.lang.Math.*;

interface Area
{
	final static float pi=3.14F;
	float compute(float x, float y);
}

class Rectangle implements Area
{
	public float compute(float x, float y)
	{
		return(x*y);
	}
}

class Square extends Rectangle implements Area
{
	public float compute(float x, float y)
	{
		return(x*x);
	}
}

class Circle implements Area
{
	public float compute(float x, float y)
	{
		return(pi*x*x);
	}
}

class ClassInterface
{
	public static void main(String args[])
	{
		Rectangle rect = new Rectangle();
		Circle cir = new Circle();
		Square sqr = new Square();
		
		Area area;
		
		area=rect;
		System.out.println("Area of Rectangle= "+area.compute(10,20));
		area=cir;
		System.out.println("Area of Circle= "+area.compute(10,0));
		area=sqr;
		System.out.println("Area of Square= "+area.compute(10,0));
	}
}