// Classes & Methods
import java.io.*;

class Class
{
	public static void main(String args[])throws IOException
	{
		One A=new One();
		A.get_data(15,10);
		int a=A.rectArea();
		System.out.println(a);
		
	}
}

class One
{

	int l,w;
	
	void get_data(int x, int y)
	{
		l=x;
		w=y;
	}
	
	int rectArea()
	{
	int area=l*w;
	return area;
	}
}