import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

public class PaintingCanvas extends Canvas implements MouseMotionListener, MouseListener {

    private ArrayList<Point> points = new ArrayList<Point>();

    public PaintingCanvas(int width, int height) {
        setBounds(0, 0, width, height);
        addMouseMotionListener(this);
        addMouseListener(this);
    }

    public void paint(Graphics g) {

        for (int i = 0; i < points.size() - 2; i++) {
            Point p1 = points.get(i);
            Point p2 = points.get(i + 1);
            g.drawLine(p1.x, p1.y, p2.x, p2.y);
        }

    }

    @Override
        public void mouseDragged(MouseEvent e) {
        points.add(e.getPoint());
        repaint();
    }

}