import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.event.*;
 
public class DrawingApplet extends JApplet
{
    public void init()
    {
        DrawingAppletPanel drawingAppletPanel = new DrawingAppletPanel();
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(drawingAppletPanel.action.getUIpanel(), "North");
        getContentPane().add(drawingAppletPanel);
    }
 
    public static void main(String[] args)
    {
        JApplet applet = new DrawingApplet();
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().add(applet);
        f.setSize(400,300);
        f.setLocation(200,200);
        applet.init();
        applet.start();
        f.setVisible(true);
    }
}
 
class DrawingAppletPanel extends JPanel
{
    DrawingAppletAction action;
    List lineList, liveList;
    Color color;
 
    public DrawingAppletPanel()
    {
        lineList = new ArrayList();
        liveList = new ArrayList();
        color = Color.black;
        setBackground(Color.white);
        action = new DrawingAppletAction(this);
        addMouseListener(action);
        addMouseMotionListener(action);
    }
 
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setStroke(new BasicStroke(2f));
        g2.setPaint(color);
        for(int i = 0; i < liveList.size(); i++)
            g2.draw((Line2D)liveList.get(i));
 
        for(int i = 0; i < lineList.size(); i++)
            g2.draw((Line2D)lineList.get(i));
    }
 
    public List getLiveList()
    {
        return liveList;
    }
 
    public List getLineList()
    {
        return lineList;
    }
 
    public void setColor(Color c)
    {
        color = c;
        repaint();
    }
 
    public void clear()
    {
        liveList.clear();
        lineList.clear();
        repaint();
    }
}
 
class DrawingAppletAction extends MouseInputAdapter
{
    DrawingAppletPanel drawPanel;
    boolean dragging;
    Point start, end;
 
    public DrawingAppletAction(DrawingAppletPanel dap)
    {
        drawPanel = dap;
        dragging = false;
        start = new Point();
    }
 
    public void mousePressed(MouseEvent e)
    {
        start.x = e.getX();
        start.y = e.getY();
        dragging = true;
    }
 
    public void mouseReleased(MouseEvent e)
    {
        List list = drawPanel.getLiveList();
        drawPanel.getLineList().addAll(list);
        list.clear();
        dragging = false;
        drawPanel.repaint();
    }
 
    public void mouseDragged(MouseEvent e)
    {
        if(dragging)
        {
            end = e.getPoint();
            List list = drawPanel.getLiveList();
            list.add(new Line2D.Double(start, end));
            start = end;
            drawPanel.repaint();
        }
    }
 
    public Box getUIpanel()
    {
        final JButton
            blackButton = new JButton(" "),
            redButton   = new JButton(" "),
            blueButton  = new JButton(" "),
            clearButton = new JButton("clear");
        blackButton.setBackground(Color.black);
        redButton.setBackground(Color.red);
        blueButton.setBackground(Color.blue);
        ActionListener l = new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                JButton button = (JButton)e.getSource();
                if(button == clearButton)
                    drawPanel.clear();
                else
                    drawPanel.setColor(button.getBackground());
            }
        };
        JButton[] buttons = {
            blackButton, redButton, blueButton, clearButton
        };
        Dimension d = clearButton.getPreferredSize();
        Box box = Box.createHorizontalBox();
        box.add(Box.createHorizontalGlue());
        for(int i = 0; i < buttons.length; i++)
        {
            buttons.setPreferredSize(d);

box.add(buttons[i]);

box.add(Box.createHorizontalGlue());

buttons[i].addActionListener(l);

}

return box;

}

}

 