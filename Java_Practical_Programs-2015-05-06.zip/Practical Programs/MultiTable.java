// Generate Multiplication Table
import java.io.*;

class MultiTable
{
	public static void main(String args[])throws IOException
	{
		DataInputStream disObj = new DataInputStream(System.in);
		
		int table, i;
		
		System.out.print("Enter the tables to print: ");
		table=Integer.parseInt(disObj.readLine());
		
		System.out.println("Tables of "+table+":");
		for(i=1;i<=10;i++)
		{
		System.out.println(table+"X"+i+"="+table*i);
		}

	}
}