//WAP to create a class Cone use method it should display area of cone & volume of cone, also use constructor.
import java.lang.Math.*;

class AreaVolumeCone
{
		float r,h;
		static float pi=3.14f;
		
		AreaVolumeCone(float a, float b)
		{
			r=a;
			h=b;
		}
		
		void ConeArea()
		{
			double ca;
			ca=pi*r*(r+(Math.sqrt((h*h)+(r*r))));
			System.out.println("");
			System.out.println("Area of Cone is: "+ca);
		}
		
		void ConeVolume()
		{
			double va;
			va=pi*(r*r)*h/3;
			System.out.println("");
			System.out.println("Volume of Cone is: "+va);
		}
		
		public static void main(String args[])
		{
			int r=Integer.parseInt(args[0]);
			int h=Integer.parseInt(args[1]);
			AreaVolumeCone A=new AreaVolumeCone(r,h);
			A.ConeArea();
			A.ConeVolume();
		}
}