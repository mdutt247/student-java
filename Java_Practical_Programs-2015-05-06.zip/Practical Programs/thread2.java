import java.io.*;

class one extends Thread
{
	public void run()
	{
		int i;
		for(i=1;i<=10;i++)
		{
			if(i==1)
			yield();
			System.out.println("Thread ONE");
		}
		System.out.println("Exit ONE");
	}
}

class two extends Thread
{
	public void run()
	{
		int i;
		for(i=1;i<=5;i++)
		{
			System.out.println("Thread TWO");
			if(i==3)
			stop();
		}
		System.out.println("Exit TWO");
	}
}

class three extends Thread
{
	public void run()
	{
		int i;
		for(i=1;i<=5;i++)
		{
			System.out.println("Thread THREE");
			if(i==1)
			try
			{
				sleep(1000);
			}
			catch(Exception e)
			{
			}
		}
		System.out.println("Exit THREE");
	}
		
}


public class thread2
{
	public static void main(String args[])
	{
		one A=new one();
		two B=new two();
		three C=new three();
		A.start();
		B.start();
		C.start();
		System.out.println("Exit MAIN");
	}
}