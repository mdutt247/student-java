import java.io.*;

class StringPalindrome
{
	public static void main(String args[]) throws IOException
	{
		String a="";
		String b="";
		
		int len=0;
		int i=0;
		
		a=args[0];
		len=a.length();
		
		for(i=len-1; i>=0; i--)
		{
			b=b+a.charAt(i);
		}
		
		if(a.equals(b))
		{
			System.out.println("Given string is a Palindrome");
		}
		else
		{
			System.out.println("Given string is NOT a Palindrome");
		}
		
	}
	
}