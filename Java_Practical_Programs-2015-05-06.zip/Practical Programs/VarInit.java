// My first JAVA Program

class VarInit
{
	public static void main(String args[])
	{
		int a=777;
		System.out.println("Value of A is: "+a);
	}
}