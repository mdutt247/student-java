import java.io.*;
class PatternMw
{
public static void main(String args[])throws IOException
{
try
{
int n,i,j;
char m;

DataInputStream A= new DataInputStream(System.in);
System.out.println("Enter The Following For Specific Pattern:");
System.out.println("Enter 1 For: M Shaped Pattern");
System.out.println("Enter 2 For: W Shaped Pattern");
n=Integer.parseInt(A.readLine());

System.out.println("Enter The Character OF Which You Want For Specific Pattern:");
m = (char)A.read();

if(n==1)
{
System.out.println("M Shaped Pattern");
for(i=1;i<=5;i++)
   {
   
      for(j=1;j<=i;j++)
      {
		System.out.print(m);
	  }
	  for(int k=5;k>=i;k--)
      {
	   System.out.print(" ");
	
	  } 
	  for(int s=5;s>=i;s--)
      {
	   System.out.print(" ");
	
	  } 
      for(j=1;j<=i;j++)
      {
	   
		System.out.print(m);
	  }
  
    System.out.print('\n');
   }
}
else if(n==2)
{
System.out.println("W Shaped Pattern");
for(i=5;i>=1;i--)
   {
   
      for(j=1;j<=i;j++)
      {
		System.out.print(m);
	  }
	  for(int k=5;k>=i;k--)
      {
	   System.out.print(" ");
	
	  } 
	  for(int s=5;s>=i;s--)
      {
	   System.out.print(" ");
	
	  } 
      for(j=1;j<=i;j++)
      {
	   
		System.out.print(m);
	  }
	  
    System.out.print('\n');
   }
}

else
{
System.out.println("You Entered Wrong Input,Try Again Later");
}
}
catch(Exception e)
{
}
}
}
