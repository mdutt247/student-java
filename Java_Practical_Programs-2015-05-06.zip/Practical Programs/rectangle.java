import java.io.*;

class rectangle
{
	public static void main(String args[])throws IOException
	{
		int l=0, b=0, area=0, per=0;
		
		l=Integer.parseInt(args[0]);
		b=Integer.parseInt(args[1]);
		
		area=l*b;
		per=2*(l+b);
		
		System.out.println("Area of Rectangle is: "+area);
		System.out.println("Perimeter of Rectangle is: "+per);
	}
}