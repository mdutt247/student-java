// Fibonacci Series
import java.io.*;

class b
{
	public static void main(String args[])throws IOException
	{
		
		int f0=0,f1=1,fn, i,n;
		System.out.print("Enter length of Series: ");
		DataInputStream F = new DataInputStream(System.in);
		n=Integer.parseInt(F.readLine());
		System.out.println("Fibonacci Series: ");
		System.out.print("0 1 ");
		 for(i=1;i<=n-2;i++)
		{
			fn=f0+f1;
			f0=f1;
			f1=fn;
			System.out.print(fn+" ");
		}

		
	}
}