
public class d2b //Decimal to Binary
{
	public static void main(String args[])
	{
		int a;
        int i = 0;
        int b[] = new int[10];

        a = Integer.parseInt(args[0]);
        while (a != 0)
        {
            i++;
            b[i] = a % 2;
            a = a / 2;
        }
		
		System.out.print("Binary is: ");
		
        for (int j = i; j > 0; j--)
        {
            System.out.print(b[j]);
        }
		
	}
}