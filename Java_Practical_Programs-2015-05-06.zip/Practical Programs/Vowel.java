import java.io.*;

class Vowel
{
	public static void main(String args[])throws IOException
	{
	char str[20];
	int i=0;
	DataInputStream dis= new DataInputStream(System.in);
	
	str=dis.read();
	
	System.out.println(str.charAt(2));
	
	while(str.charAt(i)!="")
		{
			if(str.charAt(i)=='a')
			{
			System.out.println("VOW");
			}
			i++;
		}
	}
	
}
