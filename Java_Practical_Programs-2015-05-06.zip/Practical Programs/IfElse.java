// If-Else Condition in JAVA

class IfElse
{
	public static void main(String args[])
	{
		int a=20, b=10;
		
		System.out.println("If-Else Condition:\n");
		
		if(a>b)
		{
			System.out.println("A is greater than B");
		}
		else
		{
			System.out.println("B is greater than A");
		}
	}
}