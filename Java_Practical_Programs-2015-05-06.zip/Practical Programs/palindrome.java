import java.io.*;

class palindrome
{
	public static void main(String args[])
	{
		System.out.println("Enter a string:");
	}
}