// command line program to accept three no and find greatest among them
import java.io.*;

class b6
{
public static void main(String args[])
{
int a,b,c;
a= Integer.parseInt(args[0]);
b= Integer.parseInt(args[1]);
c= Integer.parseInt(args[2]);

if (a>b && a>c)
{System.out.println("The greatest no is :"+a);}
else if (b>c && b>a)
{System.out.println("The greatest no is :"+b);}
else if (c>b && c>a)
{System.out.println("The greatest no is :"+c);}

}
}