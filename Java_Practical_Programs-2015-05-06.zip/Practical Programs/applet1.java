//<APPLET CODE="applet1.class" WIDTH=700 HEIGHT=500></APPLET>

import java.applet.*;
import java.awt.*;

public class applet1 extends Applet
{
	Label label1 = new Label("Label at (10,10)");
	Label label2 = new Label("Label at (100,100)");
	Button button1 = new Button("Button at (150,150)");
	Button button2 = new Button("Button at (200,200)");
	TextField textfield1 = new TextField(10);
	TextArea textarea1 = new TextArea(20,20);
	
	public void init()
	{
		FlowLayout f1 = new FlowLayout(FlowLayout.LEFT);
		setLayout(null);
		
		label1.setBounds(100,100,350,90);
		label2.setBounds(150,150,300,60);
		
		button1.setBounds(150,150,150,30);
		button2.setBounds(200,200,250,60);
		
		textfield1.setBounds(200,400,200,100);
		
		textarea1.setBounds(400,300,350,60);
		
	//	add(label1);
	//	add(label2);
		
	//	add(button1);
	//	add(button2);
		
		add(textfield1);
		
	//	add(textarea1);
	}
}

