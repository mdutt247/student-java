// Input Values from User in JAVA
import java.io.*;

class InputValue
{
	public static void main(String args[])throws IOException
	{
		DataInputStream disObj = new DataInputStream(System.in);
		
		String name;
		int age;
		
		System.out.println("Enter your name: ");
		name=disObj.readLine();
		
		System.out.println("Enter your age: ");
		age=Integer.parseInt(disObj.readLine());
		
		System.out.println("");
		System.out.println("Your name is: "+name);
		System.out.println("Your age is: "+age);
	}
}