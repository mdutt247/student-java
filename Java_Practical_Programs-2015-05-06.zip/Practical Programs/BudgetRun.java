import java.io.*;
import homepack.*;

class BudgetRun
{
		void calc(float sal, float allw, float food, float cloth, float edu)
		{
			float save=0.0f;
			save=(sal+allw)-(food+cloth+edu);
			System.out.println("");
			System.out.println("Savings of the family: "+save);
		}
		
		public static void main(String args[]) throws IOException
		{
			income objInc = new income();
			objInc.getincome();
			float salary=objInc.salary;
			float allowance=objInc.allowance;
				
			expenditure objExp = new expenditure();
			objExp.getexpenditure();
			float food=objExp.food;
			float clothing=objExp.clothing;
			float education=objExp.education;
			
			BudgetRun objBR = new BudgetRun();
			objBR.calc(salary,allowance,food,clothing,education);
			
		}
	
}