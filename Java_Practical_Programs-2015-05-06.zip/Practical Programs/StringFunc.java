import java.io.*;

class StringFunc
{
	public static void main(String args[])
	{
	String ip;
	
	ip=args[0];
	
	int len;
	
	len = ip.length();
	
	System.out.println(len);
	}
}