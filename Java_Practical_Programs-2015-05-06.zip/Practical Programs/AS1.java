import java.io.*;

class one extends Thread
{
	public void run()
	{
		int i;
		for(i=0;i<100;i++)
		{
			System.out.println("ONE");
		}
		System.out.println("Exit ONE");
	}
}

class two extends Thread
{
	public void run()
	{
		int i;
		for(i=0;i<100;i++)
		{
			System.out.println("TWO");
		}
		System.out.println("Exit TWO");
	}
}

public class thread1
{
	public static void main(String args[])
	{
		one A=new one();
		A.start();
		new two().start();
	}
}