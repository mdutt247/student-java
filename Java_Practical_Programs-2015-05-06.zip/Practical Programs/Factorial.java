// Factorial of a Number
import java.io.*;

class Factorial
{
	public static void main(String args[])throws IOException
	{
		DataInputStream disObj = new DataInputStream(System.in);
		
		int num=0,fact=1,i;
		
		System.out.print("Enter a Number: ");
		num=Integer.parseInt(disObj.readLine());
		
		for(i=num;i>=1;i--)
		{
		fact=fact*i;
		}
		System.out.println("Factorial is: "+fact);
		
	}
}