//Q4: WAP to create a class Cuboid use method it should display area of Cuboid & volume of Cuboid, also use constructor.
import java.lang.Math.*;

class AreaVolCuboid
{
		float w,l,h;

		AreaVolCuboid(float a, float b, float c)
		{
			w=a;
			l=b;
			h=c;
		}
		
		void CuboidArea()
		{
			double ca;
			ca=(2*w*l)+(2*l*h)+(2*h*w);
			System.out.println("");
			System.out.println("Area of Cuboid is: "+ca);
		}
		
		void CuboidVolume()
		{
			double cv;
			cv=w*l*h;
			System.out.println("");
			System.out.println("Volume of Cuboid is: "+cv);
		}
		
		public static void main(String args[])
		{
			int a=Integer.parseInt(args[0]);
			int b=Integer.parseInt(args[1]);
			int c=Integer.parseInt(args[2]);
			AreaVolCuboid A=new AreaVolCuboid(a,b,c);
			A.CuboidArea();
			A.CuboidVolume();
		}
}