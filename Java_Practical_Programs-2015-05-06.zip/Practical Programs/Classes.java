class One
{
int l,w;
void get_data(int x, int y)
{
l=x;
w=y;
}
int rectArea()
{
int area= l*w;
return area;
}
}
class Classes
{
public static void main( String args[])
{
One A= new One();
A.get_data(15,10);
int a= A.rectArea();
System.out.print(a);
}
}