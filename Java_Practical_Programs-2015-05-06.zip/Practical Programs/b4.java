//Prime no by command line
import java.io.*;
class b4
{
public static void main(String args [])throws IOException
{
int num,i,j;

num=Integer.parseInt(args[0]);
i=2;
while(i<=num-1)
{
    if(num%i==0)
    {
     System.out.println("Not A Prime Number ");
     break;
    }
    i++;
}
if ((num==i)||(num==1))
{
System.out.println("It Is a Prime Number ");
}


}

}

