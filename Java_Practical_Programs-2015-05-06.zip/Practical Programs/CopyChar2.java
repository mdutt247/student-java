// Copying Characters
import java.io.*;

class CopyChar2
{
	public static void main(String args[])throws IOException
	{
		
		File outFile = new File(args[1]);
			
		FileWriter outs=new FileWriter(outFile);
		
		int ch, i;
		ch=args[0].length();
		i=ch;
		
		
		while(i != 0)
		{
			
			outs.write(args[0].charAt(ch-i));
			i--;
		}
		
		System.out.println("Your output is delivered!");
			
		outs.close();
	}
}