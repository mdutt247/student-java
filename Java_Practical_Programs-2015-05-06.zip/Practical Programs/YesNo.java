// Trial
import java.io.*;

class YesNo
{
	public static void main(String args[])throws IOException
	{
		int x=1;
		
		if(x--)
		{
		System.out.println("Yes");
		}
		else
		{
		System.out.println("No");
		}
		
		//System.out.println("Sum is: "+sum);
	}
}