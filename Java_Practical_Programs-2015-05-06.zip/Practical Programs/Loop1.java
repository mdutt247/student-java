//Infinite Loop

import java.io.*;

class Loop1
{
	public static void main(String args[])throws IOException
	{
		int m=10, n=7;
		
		
		while(m%n>=0)
		{
		m=m+1;
		n=n+2;
		
		System.out.print("M: "+m);
		System.out.print(" N: "+n);
		System.out.println();
		}

	}
}