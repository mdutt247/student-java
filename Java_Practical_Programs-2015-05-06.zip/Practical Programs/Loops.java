// Loops in JAVA

class Loops
{
	public static void main(String args[])
	{
		int a=1, b=1, c=1;
		
		System.out.println("For Loop:\n");
		for(;a<=10;a++)
		{
			System.out.print(a+"\n");
		}
		System.out.println("");
		
		System.out.println("While Loop:\n");
		while(b<=10)
		{
		System.out.print(b+"\n");
		b++;
		}
		System.out.println("");
		
		System.out.println("Do-While Loop:\n");
		do
		{
		System.out.print(c+"\n");
		c++;
		}
		while(c<=10);
		System.out.println("");
	}
}