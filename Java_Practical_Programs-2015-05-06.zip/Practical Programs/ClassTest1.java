import java.io.*;

class ClassTest1
{
	public static void main(String arga[])throws IOException
	{
	String[] L1= new String[4];
	String[] L1A= new String[4];
	String[] L2= new String[4];
	String[] L2A= new String[4];
	String[] L3= new String[4];
	String[] L3A= new String[4];
	String ANS;
	int Count=0, Grand=0;
	int i, L1Base=0, L1Total=500, L1Grand=0;
	int j, L2Base=0, L2Total=500, L2Grand=0;
	int k, L3Base=0, L3Total=500, L3Grand=0;
	int skipcount=0, skip=0;
	
	//Question-Answers for Level 1
	L1[0]="1. What is the Capital of India?";
	L1A[0]="DELHI";
	
	L1[1]="2. What is the Economic Capital of India?";
	L1A[1]="MUMBAI";
	
	L1[2]="3. Which is the Largest Continent on the World?";
	L1A[2]="ASIA";
	
	//Question-Answers for Level 2
	L2[0]="1. Which is the latest version of Windows?";
	L2A[0]="WINDOWS 8";
	
	L2[1]="2. iPhone is made by?";
	L2A[1]="APPLE";
	
	L2[2]="3. Which is the most populated country?";
	L2A[2]="CHINA";
	
	//Question-Answers for Level 3
	L3[0]="1. Which is the highest grosser movie in Indian Film industry?";
	L3A[0]="DHOOM 3";
	
	L3[1]="2. Which was the last movie of Shah Rukh Khan?";
	L3A[1]="CHENNAI EXPRESS";
	
	L3[2]="3. Which is the upcoming movie of superstar **RAJNIKANT**?";
	L3A[2]="KOCHADAIIYAAN";
	
	DataInputStream qin = new DataInputStream(System.in);
	
	System.out.println("\nWelcome to KBC 2014");
	System.out.println("\nAll your ANSWERS must be in CAPS!\nUse SKIP Lifeline wherever needed.");
	System.out.println("\nLevel 1: (3 Questions)");

	for(i=0;i<=2;)
	{
		System.out.print(L1[i]+" Ans: ");
		ANS=qin.readLine();
			if(ANS.equals(L1A[i]))
			{
			L1Total=(L1Total)+(L1Base*2);
			L1Base=L1Base+500;
			i++;
			Count++;
			L1Grand=L1Total;
			System.out.println("You have earned: Rs."+L1Grand+"\n");
			}
			else if(ANS.equals("SKIP") && skipcount==0)
			{
			skipcount++;
			L1Total=(L1Total)+(L1Base*2);
			L1Base=L1Base+500;
			i++;
			Count++;
			L1Grand=L1Total;
			System.out.println("You have earned: Rs."+L1Grand+"\n");
			}
			else if(ANS.equals("SKIP") && skipcount>=1)
			{
			System.out.println("You have used SKIP lifeline already!\n");
			}
			else
			{
			break;
			}
	}
	
	if(Count==3)
	{
		System.out.print("\nWould you like to continue to Level 2? (YES/NO) Ans: ");
		ANS=qin.readLine();
		if(ANS.equals("YES"))
		{
			System.out.println("\nLevel 2: (3 Questions)");
			for(i=0;i<=2;)
			{
				System.out.print(L2[i]+" Ans: ");
				ANS=qin.readLine();
					if(ANS.equals(L2A[i]))
					{
					L2Total=(L2Total)+(L2Base*2);
					L2Base=L2Base+500;
					i++;
					Count++;
					L2Grand=L2Total;
					System.out.println("You have earned: Rs."+(L1Grand+L2Grand)+"\n");
					}
					else if(ANS.equals("SKIP") && skipcount==0)
					{
					skipcount++;
					L2Total=(L2Total)+(L2Base*2);
					L2Base=L2Base+500;
					i++;
					Count++;
					L2Grand=L2Total;
					System.out.println("You have earned: Rs."+(L1Grand+L2Grand)+"\n");
					}
					else if(ANS.equals("SKIP") && skipcount>=1)
					{
					System.out.println("You have used SKIP lifeline already!\n");
					}
					else
					{
					L2Grand=L2Grand*1/3;
					L1Grand=L1Grand*2/3;
					break;
					}
			}
			}
			
	}
	
	if(Count==6)
	{
		System.out.print("\nWould you like to continue to Level 3? (YES/NO) Ans: ");
		ANS=qin.readLine();
		if(ANS.equals("YES"))
		{
		System.out.println("\nLevel 3: (3 Questions)");
		for(k=0;k<=2;)
		{
			System.out.print(L3[k]+" Ans: ");
			ANS=qin.readLine();
				if(ANS.equals(L3A[k]))
				{
				L3Total=(L3Total)+(L3Base*2);
				L3Base=L3Base+500;
				k++;
				Count++;
				L3Grand=L3Total;
				System.out.println("You have earned: Rs."+(L1Grand+L2Grand+L3Grand)+"\n");
				}
				else if(ANS.equals("SKIP") && skipcount==0)
					{
					skipcount++;
					L3Total=(L3Total)+(L3Base*2);
					L3Base=L3Base+500;
					k++;
					Count++;
					L3Grand=L3Total;
					System.out.println("You have earned: Rs."+(L1Grand+L2Grand+L3Grand)+"\n");
					}
					else if(ANS.equals("SKIP") && skipcount>=1)
					{
					System.out.println("You have used SKIP lifeline already!\n");
					}
					else
					{
					L2Grand=(L1Grand+L2Grand)*3/4;
					L1Grand=L3Grand*1/4;
					L3Grand=0;
					break;
					}
		}
		}
	}
	
	//WIN Amount
	Grand=L1Grand+L2Grand+L3Grand;
	if(Grand>0)
	{
	System.out.println("\n***GOOD ATTEMPT! YOU HAVE WON RS."+Grand+"***");
	java.awt.Toolkit.getDefaultToolkit().beep();
	}
	else if(Grand==10500)
	{
	System.out.println("\n*****CONGRATS! YOU HAVE WON KBC 2014 WITH RS."+Grand+"*****");
	java.awt.Toolkit.getDefaultToolkit().beep();
	}
	else
	{
	System.out.println("\007\n***NO PRIZE! BETTER LUCK NEXT TIME!***");
	}
	
	}
}