// Whether Prime Number or No
import java.io.*;

class PrimeCheck
{
	public static void main(String args[])throws IOException
	{
		DataInputStream disObj = new DataInputStream(System.in);
		
		int num=0,i,flag=1;
		
		System.out.print("Enter a Number: ");
		num=Integer.parseInt(disObj.readLine());
		
		for(i=2;i<=num-1;i++)
		{
			if(num%i==0)
			{
			flag=0;
			break;
			}
		}
		
		if(flag!=0)
		{
		System.out.println("It is a Prime Number");
		}
		else
		{
		System.out.println("It is NOT a Prime Number");
		}
		
		
	}
}