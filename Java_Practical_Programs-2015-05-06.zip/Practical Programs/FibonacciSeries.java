// Fibonacci Series
import java.io.*;

class FibonacciSeries
{
	public static void main(String args[])throws IOException
	{
		
		int f0=0,f1=1,fn, i;
		
		System.out.println("Fibonacci Series: ");
		System.out.print("0 1 1 ");
		 for(i=0;i<=10;i++)
		{
			fn=f0+f1;
			f0=f1;
			f1=fn;
			System.out.print(fn+" ");
		}

		
	}
}