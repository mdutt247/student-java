import java.io.*;
class One extends Thread
{
public void run()
{
int i,j;
for(i=1;i<10;i++)
{
if(i==1)
yield();
System.out.println("Thread one");
}
System.out.println("exit from one");
}
}
class Two extends Thread
{
int j;
public void run()
{
for(j=1;j<5;j++)
{
System.out.println("Thread B");
if (j==3)
stop();
}
System.out.println("Exit two");
}
}
class Three extends Thread
{
public void run ()
{
for(int k=1;k<=5;k++)
{
System.out.println("Thread Three");
if (k==1)
try
{
sleep(1000);
}
catch(Exception e)
{
}
}
System.out.println("Exit");
}
}
public class example_thread
{
public static void main(String args[])
{
One A = new One();
Two B = new Two();
Three C = new Three();
A.start();
B.start();
C.start();
System.out.println("Exit from Main");


}
}
