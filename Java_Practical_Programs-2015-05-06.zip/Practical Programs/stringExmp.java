import java.io.*;
class stringExmp
{
public static void main(String args[]) throws IOException
{
System.out.print("Enter The string 1:");
String a,b,c;
DataInputStream dis= new DataInputStream(System.in);
a= dis.readLine();
System.out.println(a);
System.out.print("Enter The string 2:");
b=dis.readLine();
System.out.println(b);
c=a.concat(b);
System.out.print("The Concatenate string:");
System.out.println(c);





}
}
