public class b2d //Binary to Decimal
{
    public static void main(String args[])
    {
		String str;
		double j=0;
		
		str=args[0];
		
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)== '1')
			{
				j=j+ Math.pow(2,str.length()-1-i);
			}

		}
		
		System.out.println("Decimal is: "+(int)j);
	
	}
}